package com.example.sincronica2

import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class PrincipalActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_principal)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Definir el array bidimensional de recetas
        val recetas = arrayOf(
            arrayOf("Ensalada César", "Una deliciosa ensalada con aderezo César"),
            arrayOf("Pasta Carbonara", "Pasta italiana con salsa de huevo y panceta"),
            arrayOf("Sopa de Tomate", "Sopa ligera y saludable hecha con tomates frescos"),
            arrayOf("Tacos", "Tacos mexicanos con carne y vegetales"),
            arrayOf("Paella", "Plato tradicional español de arroz con mariscos"),
            arrayOf("Pizza Margherita", "Pizza clásica italiana con queso y albahaca")
        )

        // Obtener referencia al TextView
        val textView: TextView = findViewById(R.id.text_view_list)

        // Concatenar las recetas en un solo String
        val concatenatedRecetas = recetas.joinToString(separator = "\n\n") { receta ->
            "${receta[0]}\n${receta[1]}"
        }

        // Establecer el texto en el TextView
        textView.text = concatenatedRecetas


    }
}